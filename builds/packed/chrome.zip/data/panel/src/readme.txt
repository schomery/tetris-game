blockrain.jquery.themes.js:
  url: https://github.com/Aerolab/blockrain.js/blob/3f1f74f03e5121215ed2e9166368b2ad6d375182/src/blockrain.jquery.themes.js
  md5: 4c2b34a13a3fe715d9416e9fd1fe7a28
blockrain.jquery.src.js:
  url: https://github.com/Aerolab/blockrain.js/blob/3f1f74f03e5121215ed2e9166368b2ad6d375182/src/blockrain.jquery.src.js
  md5: c52c00ae71dfc8ed2b50bc328b7e5838
blockrain.jquery.libs.js:
  url: https://github.com/Aerolab/blockrain.js/blob/3f1f74f03e5121215ed2e9166368b2ad6d375182/src/blockrain.jquery.libs.js
  md5: d0ae679e5422f994abe236a9aa76af9d
