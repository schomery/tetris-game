jquery-1.12.0.min.js
  url: http://code.jquery.com/jquery-1.12.0.min.js
  md5: cbb11b58473b2d672f4ed53abbb67336
